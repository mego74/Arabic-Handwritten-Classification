PyTorch >= 1.1.0
torchvision == 0.5.0
Pillow (PIL)
OpenCV
tqdm

